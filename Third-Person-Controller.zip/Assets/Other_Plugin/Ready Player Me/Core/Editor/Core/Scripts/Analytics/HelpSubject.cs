namespace ReadyPlayerMe.Core.Analytics
{
    public enum HelpSubject
    {
        AvatarCaching,
        Subdomain,
        AvatarConfig,
        GltfDeferAgent,
        LoadingAvatars,
        Avatars
    }
}
