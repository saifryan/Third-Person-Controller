﻿using UnityEngine;

namespace ReadyPlayerMe.Core
{
    public class AvatarData : MonoBehaviour
    {
        public string AvatarId;
        public AvatarMetadata AvatarMetadata;
    }
}
