﻿using ReadyPlayerMe.Core;

namespace ReadyPlayerMe.Loader
{
    public interface IImporter : IOperation<AvatarContext>
    {
    }
}
