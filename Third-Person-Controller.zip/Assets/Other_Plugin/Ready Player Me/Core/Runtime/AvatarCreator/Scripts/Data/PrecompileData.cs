using System;
using System.Collections.Generic;

namespace ReadyPlayerMe.AvatarCreator
{
    [Serializable]
    public struct PrecompileData
    {
        public Dictionary<string, string[]> data;
    }
}
