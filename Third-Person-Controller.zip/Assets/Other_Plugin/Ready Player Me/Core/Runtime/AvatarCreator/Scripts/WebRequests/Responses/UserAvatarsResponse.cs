using ReadyPlayerMe.Core;

namespace ReadyPlayerMe.AvatarCreator.Responses
{
    public struct UserAvatarResponse
    {
        public string Id;
        public string Partner;
        public BodyType BodyType;
    }
}
