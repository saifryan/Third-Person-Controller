﻿var rpmFrame = document.getElementById("rpm-frame");
var rpmContainer = document.getElementById("rpm-container");
var rpmHideButton = document.getElementById("rpm-hide-button");