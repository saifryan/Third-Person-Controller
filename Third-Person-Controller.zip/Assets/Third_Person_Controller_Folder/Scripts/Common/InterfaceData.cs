using UnityEngine;

// ----- Interact -----
public interface IInteractable
{
    void Interact(Transform interactor);
}